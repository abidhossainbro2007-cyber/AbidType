ABIDTYPE V3

This version connects the website to your Supabase project.

1. Open config.js
2. Replace:
   PASTE_YOUR_PUBLISHABLE_KEY_HERE
   with your copied Supabase Publishable key.
3. DO NOT paste an sb_secret key.
4. Open index.html.

The Supabase database tables/RLS must already be created using the SQL from the previous step.

For local testing, opening index.html directly may be blocked by browser security in some setups. If that happens, run the folder through a simple local web server. We can do that together next.

This V3 includes:
- Email sign-up/login
- Supabase authentication
- User profile trigger
- Typing test
- Saving results for logged-in users
- Personal typing history
- English + Bangla starter practice
